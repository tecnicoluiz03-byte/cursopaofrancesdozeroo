(function () {
  'use strict';

  /**
   * =========================================================================
   * CONFIGURAÇÃO DO PREÇO REAL DA OFERTA
   * =========================================================================
   * Os valores abaixo vêm configurados conforme a oferta atual na Cakto.
   * Mantenha vazio ('') para preservar o texto definido diretamente no HTML.
   */
  var CONFIG = {
    originalPrice: 'R$ 99,99',
    offerPrice: 'R$ 50,00',
    offerPriceWithFees: 'R$ 50,99',
  };

  function applyConfiguredPrice() {
    var oldPriceEl = document.getElementById('offer-original-price');
    var priceEl = document.getElementById('offer-price-value');
    var feesEl = document.getElementById('offer-price-fees');

    if (oldPriceEl && CONFIG.originalPrice) {
      oldPriceEl.textContent = CONFIG.originalPrice;
    }
    if (priceEl && CONFIG.offerPrice) {
      priceEl.textContent = CONFIG.offerPrice;
    }
    if (feesEl && CONFIG.offerPriceWithFees) {
      feesEl.innerHTML =
        'Com taxas: <strong>' + CONFIG.offerPriceWithFees + '</strong>';
    }
  }

  /**
   * Garante fallback visual caso alguma imagem local falhe ao carregar.
   */
  function setupImageFallbacks() {
    var images = document.querySelectorAll('.bread-image');
    images.forEach(function (img) {
      var figure = img.closest('.bread-figure');
      if (!figure) return;

      if (img.complete && img.naturalWidth === 0) {
        figure.classList.add('is-error');
        return;
      }

      img.addEventListener('error', function () {
        figure.classList.add('is-error');
      });
    });
  }

  /**
   * Verifica de forma passiva se o fluxo oficial de upsell da Cakto foi
   * carregado e renderizado corretamente antes de exibir a explicação de
   * compra em 1 clique. Não intercepta nem altera eventos dos botões.
   */
  function observeCaktoUpsellFlow() {
    var noteEl = document.getElementById('cakto-oneclick-note');
    var scriptEl = document.getElementById('cakto-upsell-script');
    var acceptEl = document.querySelector('cakto-upsell-accept');
    var rejectEl = document.querySelector('cakto-upsell-reject');

    if (!noteEl || !scriptEl || !acceptEl || !rejectEl) {
      return;
    }

    var scriptErrored = false;
    scriptEl.addEventListener('error', function () {
      scriptErrored = true;
      noteEl.hidden = true;
    });

    function isCaktoRendered() {
      if (scriptErrored) return false;
      if (
        !window.customElements ||
        !window.customElements.get('cakto-upsell-accept') ||
        !window.customElements.get('cakto-upsell-reject')
      ) {
        return false;
      }

      var acceptShadowBtn =
        acceptEl.shadowRoot &&
        acceptEl.shadowRoot.querySelector('button[part="button"]');
      var rejectShadowBtn =
        rejectEl.shadowRoot &&
        rejectEl.shadowRoot.querySelector('button[part="button"]');

      if (!acceptShadowBtn || !rejectShadowBtn) {
        return false;
      }

      var rect = acceptEl.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && !acceptShadowBtn.disabled;
    }

    function revealNoteIfReady() {
      if (isCaktoRendered()) {
        noteEl.hidden = false;
        return true;
      }
      return false;
    }

    if (revealNoteIfReady()) {
      return;
    }

    if (window.customElements && typeof window.customElements.whenDefined === 'function') {
      Promise.all([
        window.customElements.whenDefined('cakto-upsell-accept'),
        window.customElements.whenDefined('cakto-upsell-reject'),
      ])
        .then(function () {
          window.requestAnimationFrame(function () {
            if (!revealNoteIfReady()) {
              window.setTimeout(revealNoteIfReady, 150);
            }
          });
        })
        .catch(function () {
          noteEl.hidden = true;
        });
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    applyConfiguredPrice();
    setupImageFallbacks();
    observeCaktoUpsellFlow();
  });
})();
